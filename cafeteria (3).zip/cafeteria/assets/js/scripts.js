// Archivo JavaScript personalizado
console.log("Archivo scripts.js cargado correctamente.");
